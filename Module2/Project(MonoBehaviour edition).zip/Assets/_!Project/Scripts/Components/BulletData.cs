using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;

public class BulletData : MonoBehaviour, IConvertGameObjectToEntity
{
    public float Speed = 0f;

    public void Convert(Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
    {
        //Debug.Log(transform.position);

        Vector2 dir = Vector2.up;
        float angle = transform.rotation.eulerAngles.y;
        dir = Quaternion.Euler(0, 0, -angle) * dir;

        dstManager.AddComponentData<MoveData>(entity, new MoveData
        {
            Speed = Speed / 100
        });
        dstManager.AddComponentData<InputData>(entity, new InputData
        {
            Move = new float2(dir.x, dir.y)
        });
    }

}