using System;
using System.IO;
using TMPro;
using UnityEditor.PackageManager;
using UnityEngine;
using UnityEngine.UI;

public class DownloadJSON : MonoBehaviour
{
    [SerializeField] private string _fileId = "1N-6vBUGpT9CyE4Nu5Arzy1ga-q_TQxAC";
    [SerializeField] private string _fileName = "parameter.json";
    [SerializeField] private Button _button;
    [SerializeField] private TMP_Text _resultText;

    private string _filePath;

    private void Awake()
    {
        if (_button != null)
        {
            _button.onClick.AddListener(FetchData);
        }
        _filePath = Path.Combine(Application.persistentDataPath, _fileName);
    }

    private void FetchData()
    {
        if (_resultText != null) _resultText.text = "Loading...";

        StartCoroutine(GoogleDriveTools.DownloadFileToDisk(_fileId, _filePath,
            onComplete: () => _resultText.text = "Success!",
            onError: (error) => _resultText.text = $"Error: {error}"
        ));
    }
}
