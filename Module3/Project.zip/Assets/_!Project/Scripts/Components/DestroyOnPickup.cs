using System.Collections;
using System.Collections.Generic;
using Unity.Entities;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class DestroyOnPickup : MonoBehaviour, IAbilityTarget, IConvertGameObjectToEntity
{
    private Entity _entity;

    public List<GameObject> Targets { get; set; }

    public void Convert(Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
    {
        _entity = entity;
    }

    public void Execute()
    {
        var entityManager = World.DefaultGameObjectInjectionWorld.EntityManager;
        entityManager.DestroyEntity(_entity);

        Destroy(gameObject);
    }
}
