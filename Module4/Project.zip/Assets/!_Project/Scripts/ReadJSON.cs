using System;
using System.IO;
using TMPro;
using UnityEditor.PackageManager;
using UnityEngine;
using UnityEngine.UI;

public class ReadJSON : MonoBehaviour
{
    [SerializeField] private TMP_Text _infoText;
    [SerializeField] private string _fileName = "parameter.json";
    [SerializeField] private Button _button;

    private string _filePath;

    private void Awake()
    {
        if (_button != null)
        {
            _button.onClick.AddListener(OnReadButtonClick);
        }

        _filePath = Path.Combine(Application.persistentDataPath, _fileName);
    }

    private void OnReadButtonClick()
    {
        if (!File.Exists(_filePath))
        {
            _infoText.text = "File not found.";
            return;
        }

        try
        {
            string json = File.ReadAllText(_filePath);
            MyData data = JsonUtility.FromJson<MyData>(json);
            if (data != null)
            {
                _infoText.text = $"Parameter value:: {data.number}";
            }
            else
            {
                _infoText.text = "JSON parsing error";
            }
        }
        catch (System.Exception e)
        {
            _infoText.text = $"File parsing error: {e.Message}";
        }
    }

    [System.Serializable]
    private class MyData
    {
        public int number;
    }
}