using System;
using System.Collections;
using UnityEngine;

public class Lifetime : MonoBehaviour
{
    [SerializeField] private float _lifetime;
    private void Start() 
    {
        StartCoroutine(SetDeferred(OnDestroy, _lifetime));
    }

    private void OnDestroy()
    {
        Destroy(gameObject);
    }

    private IEnumerator SetDeferred(Action action, float delay = 1f)
    {
        yield return new WaitForSeconds(delay);
        action.Invoke();
    }
}
