using System.Collections;
using System.Collections.Generic;
using Unity.Entities;
using UnityEngine;

public class AddReflectionAbility : MonoBehaviour, IAbilityTarget
{
    public List<GameObject> Targets { get; set; }

    public void Execute()
    {
        foreach (var target in Targets)
        {
            var shootAbility = target.GetComponent<ShootAbility>();
            if (shootAbility != null)
            {
                shootAbility.HasReflectionAbility = true;
            }
        }
    }
}
