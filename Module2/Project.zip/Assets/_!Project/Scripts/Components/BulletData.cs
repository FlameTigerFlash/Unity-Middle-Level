using System.Collections;
using System.Collections.Generic;
using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;

public class BulletData : MonoBehaviour, IConvertGameObjectToEntity
{
    public float Speed = 0f;

    public void Convert(Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
    {
        dstManager.AddComponentData<MoveData>(entity, new MoveData
        {
            Speed = Speed / 100
        });

        Vector2 dir = Vector2.up;
        float angle = transform.rotation.eulerAngles.y;
        dir = Quaternion.Euler(0, 0, -angle) * dir;

        dstManager.AddComponentData<InputData>(entity, new InputData
        {
            Move = new float2(dir.x, dir.y)
        });
    }

}