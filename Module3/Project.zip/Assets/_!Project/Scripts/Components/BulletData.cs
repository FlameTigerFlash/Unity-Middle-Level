using Unity.Entities;
using Unity.Mathematics;
using UnityEngine;

public class BulletData : MonoBehaviour
{
    private Rigidbody _rb;

    public bool CanReflect = false;

    private void Start()
    {
        _rb = GetComponent<Rigidbody>();
    }

    public void OnCollision()
    {
        if (CanReflect)
        {
            _rb.velocity = -(_rb.velocity);
        }
        else
        {
            Destroy(gameObject);
        }
    }
}