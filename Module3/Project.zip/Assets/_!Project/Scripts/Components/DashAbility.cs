using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DashAbility : MonoBehaviour, IAbility
{
    public float Distance = 2f;

    public float DashDelay = 0.5f;

    private float _dashTime = float.MinValue;

    public void Execute()
    {
        if (Time.time < _dashTime + DashDelay)
        {
            return;
        }
        _dashTime = Time.time;

        Vector3 direction = Quaternion.Euler(0, transform.rotation.eulerAngles.y, 0) * Vector3.forward;
        Vector3 movement = direction * Distance;

        transform.position += movement;
    }
}
