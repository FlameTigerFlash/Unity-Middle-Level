using System;
using System.Collections;
using System.IO;
using UnityEngine;
using UnityEngine.Networking;

public static class GoogleDriveTools
{
    private const string DriveDownloadBase = "https://drive.google.com/uc?export=download&id=";
    public static IEnumerator DownloadFileToDisk(string fileId, string savePath, Action onComplete, Action<string> onError)
    {
        string url = DriveDownloadBase + fileId;
        using (UnityWebRequest request = UnityWebRequest.Get(url))
        {
            yield return request.SendWebRequest();

            if (request.result != UnityWebRequest.Result.Success)
            {
                onError?.Invoke($"Error while loading file: {request.error}");
                yield break;
            }
            try
            {
                string directory = Path.GetDirectoryName(savePath);
                if (!string.IsNullOrEmpty(directory) && !Directory.Exists(directory))
                    Directory.CreateDirectory(directory);

                File.WriteAllBytes(savePath, request.downloadHandler.data);
                onComplete?.Invoke();
            }
            catch (Exception e)
            {
                onError?.Invoke($"Error while saving file: {e.Message}");
            }
        }
    }
}