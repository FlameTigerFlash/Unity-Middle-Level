using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StopBullets : MonoBehaviour, IAbilityTarget
{
    public List<GameObject> Targets { get; set; }
    public void Execute()
    {
        foreach (var target in Targets)
        {
            var bulletData = target.GetComponent<BulletData>();
            if (bulletData != null)
            {
                bulletData.OnCollision();
            }
        }
    }
}
