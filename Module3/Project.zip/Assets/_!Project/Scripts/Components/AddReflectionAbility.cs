using System.Collections;
using System.Collections.Generic;
using Unity.Entities;
using UnityEngine;

public class AddReflectionAbility : MonoBehaviour, IAbilityTarget, IConvertGameObjectToEntity
{
    private Entity _entity;
    public List<GameObject> Targets { get; set; }

    public void Convert(Entity entity, EntityManager dstManager, GameObjectConversionSystem conversionSystem)
    {
        _entity = entity;
    }

    public void Execute()
    {
        foreach (var target in Targets)
        {
            var shootAbility = target.GetComponent<ShootAbility>();
            if (shootAbility != null)
            {
                shootAbility.HasReflectionAbility = true;

                var entityManager = World.DefaultGameObjectInjectionWorld.EntityManager;
                entityManager.DestroyEntity(_entity);

                Destroy(gameObject);
            }
        }
    }
}
